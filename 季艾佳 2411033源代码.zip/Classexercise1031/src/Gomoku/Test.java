package Gomoku;

public class Test {
	public static void main(String[] args) {
		Music.getInstance().init();
		View.getInstance(); 
	}
}
